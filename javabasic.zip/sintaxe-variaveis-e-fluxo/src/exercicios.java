
public class exercicios {

	public static void main(String[] args) {
	}
}